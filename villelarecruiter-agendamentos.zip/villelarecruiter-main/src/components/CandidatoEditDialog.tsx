import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { STATUS_LABELS, STATUS_ORDER, UF_LIST, type CandidatoRow, type CandidatoStatus } from "@/lib/auth";
import { useProfilesLiteQuery } from "@/lib/ats-data";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { ORIGEM_VALUES, ORIGEM_LABELS, normalizeOrigem, type OrigemCurriculo } from "@/lib/city-validation";

interface Props {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  candidato: CandidatoRow | null;
  onSaved: () => void;
}

interface StatusLogRow {
  id: string;
  status_anterior: CandidatoStatus | null;
  status_novo: CandidatoStatus;
  changed_by_nome: string | null;
  created_at: string;
}

export function CandidatoEditDialog({ open, onOpenChange, candidato, onSaved }: Props) {
  const [busy, setBusy] = useState(false);
  const [history, setHistory] = useState<StatusLogRow[]>([]);
  const { data: profiles = [] } = useProfilesLiteQuery();
  const activeProfiles = profiles.filter((p) => p.ativo !== false);
  const [agendadoPorId, setAgendadoPorId] = useState("");
  const [form, setForm] = useState({
    nome: "", telefone: "", cidade: "", estado: "" as string, email: "",
    status: "aguardando_contato" as CandidatoStatus, observacoes: "",
    data_entrevista: "", horario_entrevista: "", entrevistador: "",
    origem_curriculo: "OUTROS" as OrigemCurriculo,
  });

  const isNew = !candidato;
  // "Quem agendou" já está definido para este candidato (agendamento
  // anterior) - nesse caso o campo vira somente leitura e não pode ser
  // sobrescrito por uma edição posterior feita por outra pessoa.
  const jaTemAgendadoPor = !!candidato?.agendado_por_nome;

  useEffect(() => {
    if (!open) return;
    if (candidato) {
      setForm({
        nome: candidato.nome,
        telefone: candidato.telefone ?? "",
        cidade: candidato.cidade ?? "",
        estado: candidato.estado ?? "",
        email: candidato.email ?? "",
        status: candidato.status,
        observacoes: candidato.observacoes ?? "",
        data_entrevista: candidato.data_entrevista ?? "",
        horario_entrevista: (candidato.horario_entrevista ?? "").slice(0, 5),
        entrevistador: candidato.entrevistador ?? "",
        origem_curriculo: normalizeOrigem(candidato.origem_curriculo),
      });
      setAgendadoPorId("");
      void loadHistory(candidato.id);
    } else {
      setForm({ nome: "", telefone: "", cidade: "", estado: "", email: "", status: "aguardando_contato", observacoes: "", data_entrevista: "", horario_entrevista: "", entrevistador: "", origem_curriculo: "OUTROS" });
      setAgendadoPorId("");
      setHistory([]);
    }
  }, [candidato, open]);

  async function loadHistory(candidatoId: string) {
    const { data } = await (supabase as unknown as {
      from: (t: string) => {
        select: (s: string) => {
          eq: (c: string, v: string) => {
            order: (c: string, o: { ascending: boolean }) => {
              limit: (n: number) => Promise<{ data: StatusLogRow[] | null }>;
            };
          };
        };
      };
    })
      .from("candidato_status_log")
      .select("id,status_anterior,status_novo,changed_by_nome,created_at")
      .eq("candidato_id", candidatoId)
      .order("created_at", { ascending: false })
      .limit(50);
    setHistory(data ?? []);
  }


  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    // Campos obrigatórios quando status = agendado
    if (form.status === "agendado") {
      if (!form.data_entrevista || !form.horario_entrevista || !form.entrevistador.trim()) {
        toast.error("Para agendar, informe data, horário e entrevistador.");
        return;
      }
      // "Quem agendou" só é exigido quando o candidato ainda não possui um
      // responsável pelo agendamento - se já possui, o campo é preservado.
      if (!jaTemAgendadoPor && !agendadoPorId) {
        toast.error("Informe quem realizou o agendamento.");
        return;
      }
    }

    setBusy(true);

    const telDigits = form.telefone.replace(/\D/g, "");
    const emailNorm = form.email.trim().toLowerCase();

    // Anti-duplicata: bloqueia telefone/email já cadastrado em OUTRO candidato
    if (telDigits || emailNorm) {
      const orParts: string[] = [];
      if (telDigits) orParts.push(`telefone.eq.${telDigits}`);
      if (emailNorm) orParts.push(`email.eq.${emailNorm}`);
      let q = supabase.from("candidatos").select("id,nome").or(orParts.join(","));
      if (!isNew) q = q.neq("id", candidato!.id);
      const { data: dup } = await q.limit(1).maybeSingle();
      if (dup) {
        setBusy(false);
        toast.error(`Já existe candidato com esse telefone/email: ${dup.nome}`);
        return;
      }
    }

    const isAgendado = form.status === "agendado";
    const payloadBase: Record<string, unknown> = {
      ...form,
      telefone: telDigits,
      email: emailNorm || null,
      estado: form.estado || null,
      data_entrevista: isAgendado ? form.data_entrevista : null,
      horario_entrevista: isAgendado ? form.horario_entrevista : null,
      entrevistador: isAgendado ? form.entrevistador.trim() : null,
    };

    if (isAgendado && !jaTemAgendadoPor) {
      // Primeiro agendamento deste candidato: grava o responsável escolhido.
      const nome = activeProfiles.find((p) => p.id === agendadoPorId)?.nome ?? "";
      payloadBase.agendado_por_id = agendadoPorId;
      payloadBase.agendado_por_nome = nome;
      payloadBase.agendado_em = new Date().toISOString();
    } else if (!isAgendado) {
      // Saiu do status "agendado": limpa os dados de agendamento, assim como
      // já acontece com data/horário/entrevistador.
      payloadBase.agendado_por_id = null;
      payloadBase.agendado_por_nome = null;
      payloadBase.agendado_em = null;
    }
    // Se isAgendado && jaTemAgendadoPor: agendado_por_* não entra no payload,
    // preservando o valor já salvo mesmo que outra pessoa esteja editando.

    let error;
    if (isNew) {
      const { data: u } = await supabase.auth.getUser();
      ({ error } = await supabase.from("candidatos").insert({ ...payloadBase, recrutador_id: u.user?.id ?? null }));
    } else {
      ({ error } = await supabase.from("candidatos").update(payloadBase).eq("id", candidato!.id));
    }

    setBusy(false);
    if (error) toast.error(error.message);
    else { toast.success(isNew ? "Criado" : "Atualizado"); onSaved(); onOpenChange(false); }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>{isNew ? "Novo candidato" : "Editar candidato"}</DialogTitle></DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5 col-span-2"><Label>Nome</Label><Input required value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Telefone</Label><Input value={form.telefone} onChange={(e) => setForm({ ...form, telefone: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Cidade</Label><Input value={form.cidade} onChange={(e) => setForm({ ...form, cidade: e.target.value })} /></div>
            <div className="space-y-1.5 col-span-2">
              <Label>Estado (UF)</Label>
              <Select value={form.estado || "none"} onValueChange={(v) => setForm({ ...form, estado: v === "none" ? "" : v })}>
                <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— não informado —</SelectItem>
                  {UF_LIST.map((uf) => <SelectItem key={uf} value={uf}>{uf}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5 col-span-2">
              <Label>Origem do currículo</Label>
              <Select value={form.origem_curriculo} onValueChange={(v) => setForm({ ...form, origem_curriculo: v as OrigemCurriculo })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {ORIGEM_VALUES.map((v) => <SelectItem key={v} value={v}>{ORIGEM_LABELS[v]}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5 col-span-2"><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            <div className="space-y-1.5 col-span-2">
              <Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v as CandidatoStatus })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {STATUS_ORDER.map((s) => <SelectItem key={s} value={s}>{STATUS_LABELS[s]}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            {form.status === "agendado" && (
              <>
                <div className="space-y-1.5">
                  <Label>Data da entrevista *</Label>
                  <Input type="date" required value={form.data_entrevista} onChange={(e) => setForm({ ...form, data_entrevista: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Horário *</Label>
                  <Input type="time" required value={form.horario_entrevista} onChange={(e) => setForm({ ...form, horario_entrevista: e.target.value })} />
                </div>
                <div className="space-y-1.5 col-span-2">
                  <Label>Entrevistador responsável *</Label>
                  <Input required value={form.entrevistador} onChange={(e) => setForm({ ...form, entrevistador: e.target.value })} placeholder="Nome do entrevistador" />
                </div>
                <div className="space-y-1.5 col-span-2">
                  <Label>Quem agendou *</Label>
                  {jaTemAgendadoPor ? (
                    <div className="rounded-md border border-border bg-muted/40 px-3 py-2 text-sm">
                      <span className="font-medium">{candidato?.agendado_por_nome}</span>
                      {candidato?.agendado_em && (
                        <span className="text-xs text-muted-foreground">
                          {" "}· {new Date(candidato.agendado_em).toLocaleString("pt-BR")}
                        </span>
                      )}
                      <p className="mt-0.5 text-[11px] text-muted-foreground">
                        Responsável original pelo agendamento. Não é alterado por esta edição.
                      </p>
                    </div>
                  ) : (
                    <Select value={agendadoPorId} onValueChange={setAgendadoPorId}>
                      <SelectTrigger><SelectValue placeholder="Selecione quem realizou o agendamento" /></SelectTrigger>
                      <SelectContent>
                        {activeProfiles.length === 0 ? (
                          <div className="px-2 py-1.5 text-xs text-muted-foreground">Nenhum usuário ativo cadastrado</div>
                        ) : (
                          activeProfiles.map((p) => (
                            <SelectItem key={p.id} value={p.id}>{p.nome}</SelectItem>
                          ))
                        )}
                      </SelectContent>
                    </Select>
                  )}
                </div>
              </>
            )}
            <div className="space-y-1.5 col-span-2"><Label>Observações</Label><Textarea rows={3} value={form.observacoes} onChange={(e) => setForm({ ...form, observacoes: e.target.value })} /></div>
            {!isNew && (
              <div className="space-y-1.5 col-span-2">
                <Label>Histórico de status</Label>
                {history.length === 0 ? (
                  <p className="text-xs text-muted-foreground">Nenhuma alteração registrada.</p>
                ) : (
                  <ul className="max-h-40 overflow-y-auto space-y-1 rounded-md border border-border p-2 text-xs">
                    {history.map((h) => (
                      <li key={h.id} className="flex justify-between gap-2">
                        <span>
                          {h.status_anterior ? `${STATUS_LABELS[h.status_anterior]} → ` : ""}
                          <strong>{STATUS_LABELS[h.status_novo]}</strong>
                          {h.changed_by_nome ? ` · ${h.changed_by_nome}` : ""}
                        </span>
                        <span className="text-muted-foreground whitespace-nowrap">
                          {new Date(h.created_at).toLocaleString("pt-BR")}
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </div>
          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button type="submit" disabled={busy}>{busy ? "Salvando..." : "Salvar"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
