import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarWidget } from "@/components/ui/calendar";
import { Calendar, Clipboard, X, Users } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { MultiSelect } from "@/components/MultiSelect";
import { ORIGEM_VALUES, ORIGEM_LABELS, normalizeOrigem } from "@/lib/city-validation";
import {
  useAgendamentosQuery,
  useAgendamentoProfilesQuery,
  useProfilesLiteQuery,
  useCandidatosRealtime,
  type AgendamentoRow,
} from "@/lib/ats-data";

export const Route = createFileRoute("/_authenticated/agendamentos")({
  component: AgendamentosPage,
});

const CARD_CLS = "rounded-xl border border-brand-border bg-card shadow-[0_1px_3px_rgba(11,34,57,0.06)]";
const INPUT_CLS = "h-10 rounded-lg focus-visible:border-brand focus-visible:ring-brand/15";
const SELECT_CLS = "h-10 rounded-lg";

type DataPreset = "" | "hoje" | "amanha" | "semana" | "custom";

function toYmd(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

/** yyyy-mm-dd -> dd/mm/yyyy, sem depender de fuso (evita off-by-one). */
function formatDataBR(iso: string | null): string {
  if (!iso) return "";
  const [y, m, d] = iso.split("-");
  if (!y || !m || !d) return "";
  return `${d}/${m}/${y}`;
}

/** HH:mm:ss ou HH:mm -> HH:mm */
function formatHora(t: string | null): string {
  if (!t) return "";
  return t.slice(0, 5);
}

function cidadeUf(cidade: string | null, estado: string | null): string {
  const c = (cidade ?? "").trim();
  const uf = (estado ?? "").trim();
  if (c && uf) return `${c}/${uf}`;
  return c || uf || "";
}

function safe(v: string | null | undefined): string {
  if (v === null || v === undefined) return "";
  if (v === "null" || v === "undefined" || v === "N/A") return "";
  return v;
}

interface CopyRow {
  data: string;
  hora: string;
  candidatos: string;
  telefone: string;
  cidadeUf: string;
  tipoFranquia: string;
  origem: string;
  recrutador: string;
  agendadoPor: string;
}

function buildCopyRows(rows: AgendamentoRow[], profMap: Map<string, string>): CopyRow[] {
  return rows.map((r) => ({
    data: formatDataBR(r.data_entrevista),
    hora: formatHora(r.horario_entrevista),
    candidatos: safe(r.nome),
    telefone: safe(r.telefone),
    cidadeUf: cidadeUf(r.cidade, r.estado),
    tipoFranquia: safe(r.vaga),
    origem: safe(ORIGEM_LABELS[normalizeOrigem(r.origem_curriculo)]),
    recrutador: safe(r.recrutador_id ? profMap.get(r.recrutador_id) : ""),
    agendadoPor: safe(r.agendado_por_nome),
  }));
}

const COPY_HEADERS = [
  "DATA", "HORA", "CANDIDATOS", "TELEFONE", "CIDADE/UF", "TIPO DE FRANQUIA", "ORIGEM", "RECRUTADOR", "AGENDAMENTOS (quem agendou)",
];

function rowToTsvLine(r: CopyRow): string {
  return [r.data, r.hora, r.candidatos, r.telefone, r.cidadeUf, r.tipoFranquia, r.origem, r.recrutador, r.agendadoPor].join("\t");
}

function buildPlainText(rows: CopyRow[]): string {
  return [COPY_HEADERS.join("\t"), ...rows.map(rowToTsvLine)].join("\n");
}

function escapeHtml(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function buildHtmlTable(rows: CopyRow[]): string {
  const head = `<tr>${COPY_HEADERS.map((h) => `<th>${escapeHtml(h)}</th>`).join("")}</tr>`;
  const body = rows
    .map((r) => {
      const cells = [r.data, r.hora, r.candidatos, r.telefone, r.cidadeUf, r.tipoFranquia, r.origem, r.recrutador, r.agendadoPor];
      return `<tr>${cells.map((c) => `<td>${escapeHtml(c)}</td>`).join("")}</tr>`;
    })
    .join("");
  return `<table><thead>${head}</thead><tbody>${body}</tbody></table>`;
}

async function copyToClipboard(rows: CopyRow[]) {
  const plain = buildPlainText(rows);
  const html = buildHtmlTable(rows);
  if (typeof ClipboardItem !== "undefined" && navigator.clipboard?.write) {
    const item = new ClipboardItem({
      "text/plain": new Blob([plain], { type: "text/plain" }),
      "text/html": new Blob([html], { type: "text/html" }),
    });
    await navigator.clipboard.write([item]);
  } else {
    await navigator.clipboard.writeText(plain);
  }
}

function AgendamentosPage() {
  const { role, loading } = useAuth();
  const navigate = useNavigate();
  useCandidatosRealtime();

  // Recrutador mantém o fluxo atual do ATS — a aba Agendamentos é
  // operacional para os perfis agendamento e admin.
  useEffect(() => {
    if (!loading && role === "recrutador") navigate({ to: "/candidatos" });
  }, [role, loading, navigate]);

  const { data: rows = [], isLoading } = useAgendamentosQuery();
  const { data: profiles = [] } = useProfilesLiteQuery();
  const { data: agendamentoProfiles = [] } = useAgendamentoProfilesQuery();
  const profMap = useMemo(() => new Map(profiles.map((p) => [p.id, p.nome])), [profiles]);

  // ---- Filtros ----
  const [dataPreset, setDataPreset] = useState<DataPreset>("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [fRecrutadores, setFRecrutadores] = useState<string[]>([]);
  const [fAgendadoPor, setFAgendadoPor] = useState<string[]>([]);
  const [fFranquia, setFFranquia] = useState<string[]>([]);
  const [fOrigem, setFOrigem] = useState<string[]>([]);

  const franquiaOptions = useMemo(() => {
    const set = new Set<string>();
    for (const r of rows) { const v = (r.vaga ?? "").trim(); if (v) set.add(v); }
    return [...set].sort((a, b) => a.localeCompare(b, "pt-BR")).map((v) => ({ value: v, label: v }));
  }, [rows]);

  const { todayStr, tomorrowStr, weekStart, weekEnd } = useMemo(() => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const tomorrow = new Date(today); tomorrow.setDate(today.getDate() + 1);
    const dow = today.getDay();
    const diffToMonday = dow === 0 ? -6 : 1 - dow;
    const monday = new Date(today); monday.setDate(today.getDate() + diffToMonday);
    const sunday = new Date(monday); sunday.setDate(monday.getDate() + 6);
    return { todayStr: toYmd(today), tomorrowStr: toYmd(tomorrow), weekStart: toYmd(monday), weekEnd: toYmd(sunday) };
  }, []);

  const filtered = useMemo(() => {
    let out = rows;
    if (dataPreset === "hoje") {
      out = out.filter((r) => r.data_entrevista === todayStr);
    } else if (dataPreset === "amanha") {
      out = out.filter((r) => r.data_entrevista === tomorrowStr);
    } else if (dataPreset === "semana") {
      out = out.filter((r) => r.data_entrevista && r.data_entrevista >= weekStart && r.data_entrevista <= weekEnd);
    } else if (dataPreset === "custom") {
      if (dateFrom) out = out.filter((r) => r.data_entrevista && r.data_entrevista >= dateFrom);
      if (dateTo) out = out.filter((r) => r.data_entrevista && r.data_entrevista <= dateTo);
    }
    if (fRecrutadores.length) out = out.filter((r) => r.recrutador_id && fRecrutadores.includes(r.recrutador_id));
    if (fAgendadoPor.length) out = out.filter((r) => r.agendado_por_id && fAgendadoPor.includes(r.agendado_por_id));
    if (fFranquia.length) out = out.filter((r) => r.vaga && fFranquia.includes(r.vaga));
    if (fOrigem.length) out = out.filter((r) => fOrigem.includes(normalizeOrigem(r.origem_curriculo)));
    // Ordenação: DATA crescente, depois HORA crescente.
    return [...out].sort((a, b) => {
      const da = a.data_entrevista ?? "9999-99-99";
      const db = b.data_entrevista ?? "9999-99-99";
      if (da !== db) return da < db ? -1 : 1;
      const ha = a.horario_entrevista ?? "99:99:99";
      const hb = b.horario_entrevista ?? "99:99:99";
      if (ha !== hb) return ha < hb ? -1 : 1;
      return 0;
    });
  }, [rows, dataPreset, dateFrom, dateTo, fRecrutadores, fAgendadoPor, fFranquia, fOrigem, todayStr, tomorrowStr, weekStart, weekEnd]);

  const hasFilters = !!(dataPreset || fRecrutadores.length || fAgendadoPor.length || fFranquia.length || fOrigem.length);
  function clearFilters() {
    setDataPreset(""); setDateFrom(""); setDateTo("");
    setFRecrutadores([]); setFAgendadoPor([]); setFFranquia([]); setFOrigem([]);
  }

  // ---- Seleção ----
  const [selected, setSelected] = useState<Set<string>>(new Set());
  useEffect(() => { setSelected(new Set()); }, [rows]);
  const allFilteredSelected = filtered.length > 0 && filtered.every((r) => selected.has(r.id));
  function toggleAll() {
    setSelected((s) => {
      if (allFilteredSelected) {
        const n = new Set(s);
        for (const r of filtered) n.delete(r.id);
        return n;
      }
      const n = new Set(s);
      for (const r of filtered) n.add(r.id);
      return n;
    });
  }
  function toggleOne(id: string) {
    setSelected((s) => {
      const n = new Set(s);
      if (n.has(id)) n.delete(id); else n.add(id);
      return n;
    });
  }

  const rowsToCopy = selected.size > 0 ? filtered.filter((r) => selected.has(r.id)) : filtered;

  async function handleCopy() {
    if (!rowsToCopy.length) {
      toast.error("Nenhum agendamento encontrado para copiar.");
      return;
    }
    try {
      const copyRows = buildCopyRows(rowsToCopy, profMap);
      await copyToClipboard(copyRows);
      toast.success("Agendamentos copiados!", {
        description: `${rowsToCopy.length} agendamento${rowsToCopy.length === 1 ? "" : "s"} copiado${rowsToCopy.length === 1 ? "" : "s"} para a área de transferência.`,
      });
    } catch {
      toast.error("Não foi possível copiar. Tente novamente.");
    }
  }

  if (loading || role === "recrutador") {
    return <div className="min-h-screen grid place-items-center text-sm text-muted-foreground">Carregando...</div>;
  }

  return (
    <div className="p-4 lg:p-8 max-w-[1500px] mx-auto min-h-screen bg-brand-bg">
      <header className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div className="min-w-0">
          <h1 className="text-2xl font-semibold tracking-[-0.01em] text-brand">Agendamentos</h1>
          <div className="mt-1.5 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-brand/10 px-2.5 py-0.5 text-xs font-medium text-brand">
              <Users className="size-3" />
              <span className="font-bold tabular-nums">{filtered.length}</span> agendamentos encontrados
            </span>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1">
          <Button
            className="h-10 px-4 rounded-[10px] bg-brand text-white hover:bg-brand/90 shadow-sm gap-1.5"
            onClick={() => void handleCopy()}
            disabled={rowsToCopy.length === 0}
          >
            <Clipboard className="size-4" />
            Copiar para SharePoint
          </Button>
          <span className="text-xs text-muted-foreground">
            Copiar {rowsToCopy.length} registro{rowsToCopy.length === 1 ? "" : "s"}
          </span>
        </div>
      </header>

      <Card className={`${CARD_CLS} p-4 mb-4`}>
        <div className="flex flex-wrap items-center gap-2.5">
          <Select value={dataPreset || "todos"} onValueChange={(v) => setDataPreset(v === "todos" ? "" : (v as DataPreset))}>
            <SelectTrigger className={`w-44 ${SELECT_CLS}`}><SelectValue placeholder="Data" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todas as datas</SelectItem>
              <SelectItem value="hoje">Hoje</SelectItem>
              <SelectItem value="amanha">Amanhã</SelectItem>
              <SelectItem value="semana">Esta semana</SelectItem>
              <SelectItem value="custom">Intervalo personalizado</SelectItem>
            </SelectContent>
          </Select>

          {dataPreset === "custom" && (
            <>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="sm" className={`w-36 justify-start font-normal ${SELECT_CLS}`}>
                    <Calendar className="size-3.5 mr-1.5" /> {dateFrom ? formatDataBR(dateFrom) : "De"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <CalendarWidget mode="single" selected={dateFrom ? new Date(`${dateFrom}T00:00:00`) : undefined} onSelect={(d) => setDateFrom(d ? toYmd(d) : "")} />
                </PopoverContent>
              </Popover>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="sm" className={`w-36 justify-start font-normal ${SELECT_CLS}`}>
                    <Calendar className="size-3.5 mr-1.5" /> {dateTo ? formatDataBR(dateTo) : "Até"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <CalendarWidget mode="single" selected={dateTo ? new Date(`${dateTo}T00:00:00`) : undefined} onSelect={(d) => setDateTo(d ? toYmd(d) : "")} />
                </PopoverContent>
              </Popover>
            </>
          )}

          <MultiSelect
            className={`w-52 ${SELECT_CLS}`}
            placeholder="Recrutador"
            value={fRecrutadores}
            onChange={setFRecrutadores}
            options={profiles.map((p) => ({ value: p.id, label: p.nome }))}
          />

          <Select value={fAgendadoPor[0] ?? "todos"} onValueChange={(v) => setFAgendadoPor(v === "todos" ? [] : [v])}>
            <SelectTrigger className={`w-52 ${SELECT_CLS}`}><SelectValue placeholder="Quem agendou" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Quem agendou (todos)</SelectItem>
              {agendamentoProfiles.map((p) => <SelectItem key={p.id} value={p.id}>{p.nome}</SelectItem>)}
            </SelectContent>
          </Select>

          <MultiSelect
            className={`w-52 ${SELECT_CLS}`}
            placeholder="Tipo de franquia"
            value={fFranquia}
            onChange={setFFranquia}
            options={franquiaOptions}
          />

          <MultiSelect
            className={`w-44 ${SELECT_CLS}`}
            placeholder="Origem"
            value={fOrigem}
            onChange={setFOrigem}
            options={ORIGEM_VALUES.map((v) => ({ value: v, label: ORIGEM_LABELS[v] }))}
            searchable={false}
          />

          {hasFilters && (
            <Button variant="ghost" size="sm" onClick={clearFilters} className="gap-1 text-muted-foreground">
              <X className="size-3.5" /> Limpar filtros
            </Button>
          )}
        </div>
      </Card>

      <Card className={`${CARD_CLS} overflow-hidden`}>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-brand-border bg-muted/40 text-left text-xs uppercase tracking-wide text-muted-foreground">
                <th className="px-3 py-2.5 w-10">
                  <Checkbox checked={allFilteredSelected} onCheckedChange={toggleAll} aria-label="Selecionar todos" />
                </th>
                <th className="px-3 py-2.5 whitespace-nowrap">DATA</th>
                <th className="px-3 py-2.5 whitespace-nowrap">HORA</th>
                <th className="px-3 py-2.5 whitespace-nowrap">CANDIDATOS</th>
                <th className="px-3 py-2.5 whitespace-nowrap">TELEFONE</th>
                <th className="px-3 py-2.5 whitespace-nowrap">CIDADE/UF</th>
                <th className="px-3 py-2.5 whitespace-nowrap">TIPO DE FRANQUIA</th>
                <th className="px-3 py-2.5 whitespace-nowrap">ORIGEM</th>
                <th className="px-3 py-2.5 whitespace-nowrap">RECRUTADOR</th>
                <th className="px-3 py-2.5 whitespace-nowrap">AGENDAMENTOS (quem agendou)</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr><td colSpan={10} className="px-3 py-8 text-center text-muted-foreground">Carregando...</td></tr>
              ) : filtered.length === 0 ? (
                <tr><td colSpan={10} className="px-3 py-8 text-center text-muted-foreground">Nenhum agendamento encontrado.</td></tr>
              ) : (
                filtered.map((r) => (
                  <tr key={r.id} className="border-b border-brand-border/60 last:border-0 hover:bg-muted/30">
                    <td className="px-3 py-2.5">
                      <Checkbox checked={selected.has(r.id)} onCheckedChange={() => toggleOne(r.id)} aria-label={`Selecionar ${r.nome}`} />
                    </td>
                    <td className="px-3 py-2.5 whitespace-nowrap tabular-nums">{formatDataBR(r.data_entrevista)}</td>
                    <td className="px-3 py-2.5 whitespace-nowrap tabular-nums">{formatHora(r.horario_entrevista)}</td>
                    <td className="px-3 py-2.5 font-medium text-foreground whitespace-nowrap">{r.nome}</td>
                    <td className="px-3 py-2.5 whitespace-nowrap">{safe(r.telefone)}</td>
                    <td className="px-3 py-2.5 whitespace-nowrap">{cidadeUf(r.cidade, r.estado)}</td>
                    <td className="px-3 py-2.5 whitespace-nowrap">{safe(r.vaga)}</td>
                    <td className="px-3 py-2.5 whitespace-nowrap">{ORIGEM_LABELS[normalizeOrigem(r.origem_curriculo)]}</td>
                    <td className="px-3 py-2.5 whitespace-nowrap text-muted-foreground">{r.recrutador_id ? profMap.get(r.recrutador_id) ?? "—" : "—"}</td>
                    <td className="px-3 py-2.5 whitespace-nowrap">{safe(r.agendado_por_nome) || "—"}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
