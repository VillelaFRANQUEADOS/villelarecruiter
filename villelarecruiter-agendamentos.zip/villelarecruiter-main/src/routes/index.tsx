import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/")({
  component: IndexRedirect,
});

function IndexRedirect() {
  const { user, role, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (loading) return;
    if (!user) { navigate({ to: "/login" }); return; }
    // Perfil "agendamento" abre prioritariamente a área operacional de
    // Agendamentos; demais perfis mantêm o fluxo atual (dashboard).
    if (role === "agendamento") navigate({ to: "/agendamentos" });
    else navigate({ to: "/dashboard" });
  }, [user, role, loading, navigate]);

  return (
    <div className="min-h-screen grid place-items-center text-sm text-muted-foreground">
      Carregando...
    </div>
  );
}
